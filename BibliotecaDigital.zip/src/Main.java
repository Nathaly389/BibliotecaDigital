public class Main {
    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();

        biblioteca.registrarUsuario(new Usuario("U1", "Ana"));
        biblioteca.registrarUsuario(new Usuario("U2", "Luis"));

        biblioteca.añadirLibro(new Libro("ISBN-001", "Clean Code", "Robert C. Martin", "Software"));
        biblioteca.añadirLibro(new Libro("ISBN-002", "Effective Java", "Joshua Bloch", "Java"));

        biblioteca.prestarLibro("U1", "ISBN-001");
        biblioteca.prestarLibro("U2", "ISBN-002");

        System.out.println("Libros prestados por Ana:");
        biblioteca.listarPrestados("U1").forEach(System.out::println);

        biblioteca.devolverLibro("U1", "ISBN-001");

        System.out.println("\nLibros del autor 'Bloch':");
        biblioteca.buscarPorAutor("Bloch").forEach(System.out::println);

        System.out.println("\nLibros de la categoría 'Software':");
        biblioteca.buscarPorCategoria("Software").forEach(System.out::println);
    }
}